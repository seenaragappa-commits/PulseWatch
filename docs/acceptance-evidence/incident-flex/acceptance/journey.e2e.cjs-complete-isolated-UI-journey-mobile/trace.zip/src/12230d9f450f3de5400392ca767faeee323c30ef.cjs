const {test,expect}=require('@playwright/test');
const {fork}=require('node:child_process');
const fs=require('node:fs'),path=require('node:path');
test('complete isolated UI journey',async({page,context},info)=>{
 const child=fork(path.resolve('e2e/harness.cjs'),[],{env:{...process.env,NODE_ENV:'test'},stdio:['ignore','pipe','pipe','ipc'],windowsHide:true});
 const logs={console:[],pageErrors:[],failedRequests:[],httpErrors:[],blocked:[],scenarios:[]};
 const ready=await new Promise((resolve,reject)=>{child.once('message',resolve);child.once('error',reject);child.once('exit',code=>reject(Error('Harness exited '+code)));});
 logs.database=ready.database;let seq=0;
 const command=command=>new Promise((resolve,reject)=>{const id=++seq;const listener=m=>{if(m.id===id){child.off('message',listener);m.error?reject(Error(m.error)):resolve();}};child.on('message',listener);child.send({id,command});});
 const shot=async name=>page.screenshot({path:info.outputPath(name+'.png'),fullPage:true});
 const scenario=async(name,fn)=>{try{await test.step(name,fn);logs.scenarios.push({name,status:'PASS'});}catch(error){logs.scenarios.push({name,status:'FAIL',error:error.message});await shot('failure-'+logs.scenarios.length);throw error;}};
 await context.route('**/*',route=>{if(new URL(route.request().url()).origin===ready.origin)return route.continue();logs.blocked.push(route.request().url());return route.abort();});
 page.on('console',m=>{if(m.type()==='error')logs.console.push(m.text());});page.on('pageerror',e=>logs.pageErrors.push(e.message));page.on('requestfailed',r=>logs.failedRequests.push({url:r.url(),error:r.failure()}));page.on('response',r=>{if(r.status()>=400)logs.httpErrors.push({url:r.url(),status:r.status()});});
 const row=type=>page.locator('tr.monitor-row').filter({hasText:'Browser '+type});
 try{
 await scenario('dashboard empty state and navigation',async()=>{await page.goto(ready.origin);await expect(page.getByText('No monitors yet.',{exact:false})).toBeVisible();for(const name of ['Monitors','Incidents','About','Overview']){await page.getByRole('button',{name,exact:true}).click();}await shot('empty');});
 for(const type of ['HTTP','DNS','SSL','TCP']){
 await scenario('create '+type,async()=>{await page.getByRole('button',{name:'+ Add monitor'}).click();await page.locator('[name=monitorType]').selectOption(type);await page.locator('[name=name]').fill('Browser '+type);await page.locator(type==='HTTP'?'[name=url]':'[name=domain]').fill(type==='HTTP'?'https://example.com':'example.com');await page.locator('[name=intervalSeconds]').fill('86400');await page.getByRole('button',{name:'Save monitor',exact:true}).click();await expect(row(type)).toBeVisible();});
 await scenario('edit '+type,async()=>{await row(type).getByRole('button',{name:'Edit',exact:true}).click();await page.locator(type==='HTTP'?'[name=url]':'[name=domain]').fill(type==='HTTP'?'https://example.org':'example.org');await page.getByRole('button',{name:'Save monitor',exact:true}).click();await expect(row(type)).toContainText('example.org');});
 }
 await scenario('form validation',async()=>{await page.getByRole('button',{name:'+ Add monitor'}).click();await page.getByRole('button',{name:'Save monitor',exact:true}).click();await expect(page.locator('[name=name]:invalid')).toBeVisible();await page.locator('[name=monitorType]').selectOption('DNS');await page.locator('[name=name]').fill('Invalid domain');await page.locator('[name=domain]').fill('bad..domain');await page.getByRole('button',{name:'Save monitor',exact:true}).click();await expect(page.locator('.modal .error')).toContainText('Validation failed');await shot('validation');await page.getByRole('button',{name:'Cancel',exact:true}).click();});
 await command('recover');await page.reload();
 await scenario('status history details and refresh persistence',async()=>{await expect(page.locator('tr.monitor-row')).toHaveCount(4);for(const type of ['HTTP','DNS','SSL','TCP']){await expect(row(type)).toContainText('UP');await row(type).locator('b').click();const drawer=page.getByRole('complementary',{name:'Monitor details'});await expect(drawer).toContainText('example.org');await expect(drawer.locator('tbody tr').first()).toContainText('12 ms');await shot('details-'+type);await page.getByRole('button',{name:'Close monitor details'}).click();}await shot('dashboard');});
 await scenario('three failures create one incident per monitor',async()=>{for(let i=1;i<=3;i++){await command('fail');await page.reload();await page.getByRole('button',{name:'Incidents',exact:true}).click();await expect(page.locator('button.incident')).toHaveCount(i<3?0:4);}await command('fail');await page.reload();await page.getByRole('button',{name:'Incidents',exact:true}).click();await expect(page.locator('button.incident')).toHaveCount(4);await expect(page.locator('button.incident').first()).toContainText('4 failures');await page.locator('button.incident').first().click();await expect(page.getByRole('complementary',{name:'Incident details'})).toContainText('destination refused');await shot('incident-open');});
 await command('recover');await page.waitForTimeout(16000);
 const resolved=await page.evaluate(()=>fetch('/api/incidents').then(r=>r.json()));expect(resolved.data.every(i=>i.status==='RESOLVED')).toBe(true);
 const stale=await page.getByRole('complementary',{name:'Incident details'}).innerText();logs.scenarios.push({name:'open incident drawer refreshes after recovery',status:stale.includes('RESOLVED')?'PASS':'FAIL',observed:stale});await shot('incident-after-recovery');
 await scenario('incident drawer close hit test and viewport containment',async()=>{
   const close=page.getByRole('button',{name:'Close incident details'});
   const metrics=await close.evaluate(button=>{const rect=button.getBoundingClientRect(),drawer=button.closest('.drawer'),backdrop=drawer.parentElement,hit=document.elementFromPoint(rect.left+rect.width/2,rect.top+rect.height/2),d=drawer.getBoundingClientRect(),b=backdrop.getBoundingClientRect();return {viewport:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth,button:{left:rect.left,right:rect.right,top:rect.top,bottom:rect.bottom,width:rect.width,height:rect.height},drawer:{left:d.left,right:d.right},backdrop:{left:b.left,right:b.right},hit:hit===button||button.contains(hit)};});
   logs.closeMetrics=metrics;expect(metrics.scroll).toBeLessThanOrEqual(metrics.viewport);expect(metrics.drawer.right).toBeLessThanOrEqual(metrics.viewport);expect(metrics.backdrop.right).toBeLessThanOrEqual(metrics.viewport);expect(metrics.button.left).toBeGreaterThanOrEqual(0);expect(metrics.button.right).toBeLessThanOrEqual(metrics.viewport);expect(metrics.button.width).toBeGreaterThan(0);expect(metrics.button.height).toBeGreaterThan(0);expect(metrics.hit).toBe(true);
 });
 await page.getByRole('button',{name:'Close incident details'}).click();
 await expect(page.getByRole('complementary',{name:'Incident details'})).toHaveCount(0);
 await scenario('recovery and reopened incident details',async()=>{await expect(page.locator('button.incident').first()).toContainText('RESOLVED');await page.locator('button.incident').first().click();await expect(page.getByRole('complementary',{name:'Incident details'})).toContainText('Recovered');await shot('incident-resolved');await page.getByRole('button',{name:'Close incident details'}).click();});
 await command('history');await page.getByRole('button',{name:'Overview',exact:true}).click();await row('SSL').locator('b').click();const drawer=page.getByRole('complementary',{name:'Monitor details'});
 await scenario('certificate metadata and history pagination',async()=>{await expect(drawer).toContainText('Current fixture CA');await page.getByRole('button',{name:'Next',exact:true}).click();await expect(drawer).toContainText('Page 2');const evidence=await page.evaluate(async()=>{const monitors=await fetch('/api/monitors').then(r=>r.json());const ssl=monitors.data.find(m=>m.monitorType==='SSL');return fetch('/api/monitors/'+ssl.id+'/checks?page=2&limit=20').then(r=>r.json());});expect(evidence.data.some(c=>c.certificate_issuer==='Historical fixture CA')).toBe(true);await shot('certificate-history-page2');});
 logs.scenarios.push({name:'certificate summary remains current while paging',status:(await drawer.locator('.detail-grid').innerText()).includes('Current fixture CA')?'PASS':'FAIL'});
 await scenario('repeated drawer pagination and unobstructed button hit targets',async()=>{
   logs.pagination=[];
   for(let cycle=0;cycle<3;cycle++){
     await page.getByRole('button',{name:'Previous',exact:true}).click({timeout:10000});await expect(drawer).toContainText('Page 1');
     const next=page.getByRole('button',{name:'Next',exact:true});await next.scrollIntoViewIfNeeded();
     const geometry=await next.evaluate(button=>{const rect=button.getBoundingClientRect(),hit=document.elementFromPoint(rect.x+rect.width/2,rect.y+rect.height/2),drawer=button.closest('.drawer'),history=drawer.querySelector('.history-scroll');return {receivesClick:hit===button||button.contains(hit),hit:hit?.tagName,drawerWidth:drawer.clientWidth,drawerScrollWidth:drawer.scrollWidth,historyWidth:history.clientWidth,historyScrollWidth:history.scrollWidth,display:getComputedStyle(drawer).display,direction:getComputedStyle(drawer).flexDirection};});
     logs.pagination.push(geometry);expect(geometry.receivesClick).toBe(true);expect(geometry.drawerScrollWidth).toBeLessThanOrEqual(geometry.drawerWidth);
     await next.click({timeout:10000});await expect(drawer).toContainText('Page 2');await expect(drawer.locator('.detail-grid')).toContainText('Current fixture CA');
   }
   await shot('pagination-repeated');await drawer.evaluate(element=>element.scrollTop=0);await shot('drawer-readable');
 });
 await page.getByRole('button',{name:'Close monitor details'}).click();
 await page.reload();await expect(page.locator('tr.monitor-row')).toHaveCount(4);await expect(row('SSL')).toContainText('example.org');await page.getByRole('button',{name:'Incidents',exact:true}).click();await expect(page.locator('button.incident')).toHaveCount(4);await expect(page.locator('button.incident').first()).toContainText('RESOLVED');await page.getByRole('button',{name:'Overview',exact:true}).click();
 const width=await page.evaluate(()=>({viewport:innerWidth,outerWidth,clientWidth:document.documentElement.clientWidth,meta:document.querySelector('meta[name=viewport]')?.content,document:document.documentElement.scrollWidth}));logs.scenarios.push({name:'layout matches requested viewport without overflow',status:width.document<=info.project.use.viewport.width&&width.viewport===info.project.use.viewport.width?'PASS':'FAIL',observed:{...width,requested:info.project.use.viewport.width}});await shot('layout');
 logs.scenarios.push({name:'no unexpected browser errors',status:logs.pageErrors.length||logs.failedRequests.length||logs.blocked.length||logs.httpErrors.some(r=>r.status!==400)?'FAIL':'PASS'});
 }finally{fs.writeFileSync(info.outputPath('observations.json'),JSON.stringify(logs,null,2));await command('stop');}
 expect(logs.scenarios.filter(s=>s.status==='FAIL'),'Browser acceptance defects').toEqual([]);
});
